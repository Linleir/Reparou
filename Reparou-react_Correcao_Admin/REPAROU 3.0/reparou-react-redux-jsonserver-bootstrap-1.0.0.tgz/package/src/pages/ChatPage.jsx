import { useMemo, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Layout, { BottomNavCliente, BottomNavLojista } from '../components/Layout';
import { createChat, saveReview, sendMessage } from '../features/dataSlice';
import { formatDateTime } from '../utils/format';

export default function ChatPage() {
  const { chatId } = useParams();
  const { search } = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { role, user } = useSelector((state) => state.auth);
  const lojaIdFromQuery = new URLSearchParams(search).get('lojaId');
  const lojaFallback = useSelector((state) => state.data.lojas.find((item) => item.id === lojaIdFromQuery)) || useSelector((state) => state.data.lojas[0]);
  const realChat = useSelector((state) => state.data.chats.find((item) => item.id === chatId));
  const loja = useSelector((state) => state.data.lojas.find((item) => item.id === (realChat?.lojaId || lojaIdFromQuery)));
  const [msg, setMsg] = useState('');
  const [nota, setNota] = useState(5);
  const [textoAvaliacao, setTextoAvaliacao] = useState('');
  const chat = realChat || { id: null, lojaId: lojaFallback?.id, tituloServico: lojaFallback?.servicos?.[0]?.nome || 'Serviço Geral', serviceTag: lojaFallback?.servicos?.[0]?.tag || 'Serviço', tags: lojaFallback?.tags?.slice(0,3) || [], mensagens: [], status: 'ativo', clienteId: user?.id, clienteNome: user?.nome ? `${user.nome} ${user.sobrenome||''}`.trim() : 'Cliente Teste' };
  const bottom = role === 'cliente' ? <BottomNavCliente /> : <BottomNavLojista />;

  const handleSend = async () => {
    if (!msg.trim()) return;
    if (!realChat) {
      const payload = { ...chat, id: `chat-${Date.now()}`, mensagens: [{ autor: 'cliente', texto: msg.trim(), horario: new Date().toISOString() }, { autor: 'loja', texto: 'Recebemos sua mensagem.', horario: new Date(Date.now()+1000).toISOString() }], criadoEm: new Date().toISOString(), atualizadoEm: new Date().toISOString(), avaliacaoId: null };
      const result = await dispatch(createChat(payload)).unwrap();
      setMsg('');
      navigate(`/chat/${result.id}`);
      return;
    }
    await dispatch(sendMessage({ chat: realChat, text: msg.trim() }));
    setMsg('');
  };

  const save = async () => {
    if (!textoAvaliacao.trim()) return;
    await dispatch(saveReview({ review: { id: realChat?.avaliacaoId || undefined, chatId: realChat.id, lojaId: chat.lojaId, cliente: user?.nome || 'Cliente', tituloServico: chat.tituloServico, serviceTag: chat.serviceTag, tags: chat.tags, nota, texto: textoAvaliacao, dataIso: new Date().toISOString() }, chatId: realChat.id }));
    navigate('/avaliacoes/historico');
  };

  return <Layout bottom={bottom}><div className="profile-header2 chat-header-v2 mb-3"><Link to={role==='cliente'?'/mensagens':'/lojista/chats'} className="text-white text-decoration-none">←</Link><div className="chat-shop-card d-flex gap-3 align-items-center mt-2"><img src={loja?.imagem || '/imgtst.jpg'} className="chat-shop-img" /><div><h3 className="h6 mb-1">{loja?.nome}</h3><p className="mb-1">{loja?.enderecoLinhas?.join(' • ')}</p><p className="mb-0">{loja?.telefones?.join(' • ')}</p></div></div></div><div className="card p-3 mb-5 chat-screen"><div className={`chat-top-status ${chat.status}`}>{chat.status.replaceAll('-', ' ')}</div><div className="mb-2"><span className="review-service-chip">{chat.tituloServico}</span></div><div className="mb-2">{(chat.tags||[]).map((tag)=><span key={tag} className="badge bg-secondary me-1">{tag}</span>)}</div><div className="chat-area-v2">{chat.mensagens.map((mensagem, index)=><div key={index} className={`chat-row ${mensagem.autor==='cliente'?'msg-out':'msg-in'} mb-2`}><div className={`p-2 rounded-3 shadow-sm ${mensagem.autor==='cliente'?'bg-primary text-white':'bg-light text-dark'}`} style={{maxWidth:'80%'}}><p className="mb-1">{mensagem.texto}</p><span className="d-block text-end small" style={{fontSize:'0.7rem',opacity:0.7}}>{formatDateTime(mensagem.horario)}</span></div></div>)}</div>{role==='cliente' && realChat?.status==='finalizado-avaliado' ? null : <><div className="d-flex gap-2 mt-3"><input className="form-control" placeholder="Escreva uma mensagem..." value={msg} onChange={(e)=>setMsg(e.target.value)} onKeyDown={(e)=>e.key==='Enter'&&handleSend()} /><button className="btn btn-dark" onClick={handleSend}>Enviar</button></div>{role==='cliente' && realChat && <div className="mt-4"><h6>Avaliar atendimento</h6><div className="mb-2">{[1,2,3,4,5].map((star)=><button key={star} type="button" className="star-select" onClick={()=>setNota(star)}>★</button>)}</div><textarea className="form-control mb-2" rows={3} value={textoAvaliacao} onChange={(e)=>setTextoAvaliacao(e.target.value)} placeholder="Escreva sua avaliação" /><button className="btn btn-custom" onClick={save}>Salvar avaliação</button></div>}</>}</div></Layout>;
}
