import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { loginSuccess } from '../features/authSlice';

export default function AccessPage() {
  const { clientes, lojistas, admins } = useSelector((state) => state.data);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const enter = (role) => {
    if (role === 'cliente') { dispatch(loginSuccess({ user: clientes[0], role })); navigate('/inicio'); }
    if (role === 'lojista') { dispatch(loginSuccess({ user: lojistas[0], role })); navigate('/lojista/perfil'); }
    if (role === 'admin') { dispatch(loginSuccess({ user: admins[0], role })); navigate('/admin'); }
  };
  return <Layout><div className="card p-3"><div className="bg-black text-white p-3 rounded mb-3 text-center position-relative"><Link to="/" className="position-absolute start-0 top-50 translate-middle-y ms-3 text-white text-decoration-none">←</Link><h1 className="h5 m-0">LOGIN</h1></div><h5 className="mb-3">Acessos de demonstração</h5><div className="mb-4"><p><strong>Cliente:</strong><br/>CPF 111.222.333-44<br/>Senha 123</p><button className="btn btn-primary w-100" onClick={()=>enter('cliente')}>Entrar como cliente</button></div><div className="mb-4"><p><strong>Lojista:</strong><br/>CNPJ 22.222.222/2222-22<br/>Senha 123</p><button className="btn btn-primary w-100" onClick={()=>enter('lojista')}>Entrar como lojista</button></div><div><p><strong>Administrador:</strong><br/>ID 00000000000000<br/>Senha 123</p><button className="btn btn-secondary w-100" onClick={()=>enter('admin')}>Entrar como administrador</button></div></div></Layout>;
}
