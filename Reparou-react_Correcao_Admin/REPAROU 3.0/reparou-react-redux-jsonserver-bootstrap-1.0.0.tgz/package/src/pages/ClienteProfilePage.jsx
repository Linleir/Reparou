import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Layout, { BottomNavCliente } from '../components/Layout';
import { logout } from '../features/authSlice';
import { saveClienteProfile } from '../features/dataSlice';

export default function ClienteProfilePage() {
  const { user } = useSelector((state) => state.auth);
  const cliente = useSelector((state) => state.data.clientes.find((item) => item.id === user.id));
  const [form, setForm] = useState({ nome: cliente?.nome || '', sobrenome: cliente?.sobrenome || '', perfil: { ...(cliente?.perfil || {}) } });
  const dispatch = useDispatch();
  return <Layout bottom={<BottomNavCliente />}><div className="profile-header2 mb-3 text-center"><h4 id="perfil-usuario-nome">{`${cliente?.nome || ''} ${cliente?.sobrenome || ''}`}</h4><div id="perfil-usuario-local">{cliente?.perfil?.bairro} • {cliente?.perfil?.municipio}</div></div><div className="card p-3 mb-5"><div className="mb-2"><input className="form-control" value={form.nome} onChange={(e)=>setForm({...form,nome:e.target.value})} placeholder="Nome" /></div><div className="mb-2"><input className="form-control" value={form.sobrenome} onChange={(e)=>setForm({...form,sobrenome:e.target.value})} placeholder="Sobrenome" /></div><div className="mb-2"><input className="form-control" value={form.perfil.bairro || ''} onChange={(e)=>setForm({...form,perfil:{...form.perfil,bairro:e.target.value}})} placeholder="Bairro" /></div><div className="mb-2"><input className="form-control" value={form.perfil.municipio || ''} onChange={(e)=>setForm({...form,perfil:{...form.perfil,municipio:e.target.value}})} placeholder="Município" /></div><button className="btn btn-custom w-100 mb-2" onClick={()=>dispatch(saveClienteProfile({ clienteId: cliente.id, payload: form }))}>Salvar perfil</button><Link to="/favoritos" className="btn btn-outline-dark w-100 mb-2">Ver favoritos</Link><button className="btn btn-outline-secondary w-100" onClick={()=>dispatch(logout())}>Sair</button></div></Layout>;
}
