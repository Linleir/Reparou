import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Layout, { BottomNavCliente } from '../components/Layout';
import { saveReview } from '../features/dataSlice';
import { formatDateTime } from '../utils/format';

export default function ReviewDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const review = useSelector((state) => state.data.reviews.find((item) => item.id === id));
  const loja = useSelector((state) => state.data.lojas.find((item) => item.id === review?.lojaId));
  const [nota, setNota] = useState(review?.nota || 5);
  const [texto, setTexto] = useState(review?.texto || '');
  if (!review) return null;
  return <Layout bottom={<BottomNavCliente />}><div className="profile-header2 mb-3"><Link to="/avaliacoes/historico" className="text-white text-decoration-none">←</Link><div className="d-flex gap-3 align-items-center mt-2"><img src={loja?.imagem} className="shop-img" /><div><h5 className="mb-1">{loja?.nome}</h5><div className="mb-1">{review.tituloServico}</div><div>{(review.tags||[]).map((tag)=><span key={tag} className="review-service-chip me-1">{tag}</span>)}</div><small>{formatDateTime(review.dataIso)}</small></div></div></div><div className="card p-3 mb-5"><p>Edite sua avaliação abaixo.</p><div className="mb-2">{[1,2,3,4,5].map((star)=><button key={star} type="button" className={`star-select ${star<=nota?'active':''}`} onClick={()=>setNota(star)}>★</button>)}</div><textarea className="form-control mb-3" rows={5} value={texto} onChange={(e)=>setTexto(e.target.value)} /><button className="btn btn-custom w-100" onClick={async()=>{ await dispatch(saveReview({ review: { ...review, nota, texto, dataIso:new Date().toISOString() }, chatId: review.chatId })); navigate('/avaliacoes/historico'); }}>Salvar edição</button></div></Layout>;
}
